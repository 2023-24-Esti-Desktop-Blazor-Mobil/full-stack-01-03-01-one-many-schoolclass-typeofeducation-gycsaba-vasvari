﻿using Kreta.Shared.Models.SchoolCitizens;
using Kreta.Shared.Responses;

namespace Kreta.HttpService.Services
{
    public interface ITeacherService : IBaseService<Teacher>
    {
   

    }
}
