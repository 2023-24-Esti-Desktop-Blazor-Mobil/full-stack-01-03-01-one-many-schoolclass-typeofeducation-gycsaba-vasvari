﻿using Kreta.Shared.Models.SchoolCitizens;

namespace Kreta.HttpService.Services
{
    public interface IStudentService : IBaseService<Student>
    {
    }
}
