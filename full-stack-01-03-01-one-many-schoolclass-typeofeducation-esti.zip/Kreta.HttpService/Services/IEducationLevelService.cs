﻿using Kreta.Shared.Models;

namespace Kreta.HttpService.Services
{
    public interface IEducationLavelService : IBaseService<EducationLevel>
    {
    }
}
