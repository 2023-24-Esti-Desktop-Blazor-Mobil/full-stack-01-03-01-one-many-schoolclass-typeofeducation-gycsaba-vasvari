﻿
using Kreta.Shared.Models;

namespace Kreta.HttpService.Services
{
    public interface IGradeService : IBaseService<Grade>
    {
    }
}
