﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolClasses
{
    public class SchoolClassesSubjectsViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Diákok tantárgyai";
    }
}
