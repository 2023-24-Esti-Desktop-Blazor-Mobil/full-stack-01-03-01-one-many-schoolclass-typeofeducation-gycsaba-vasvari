﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolClasses
{
    public class SchoolClassesTimeTableViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Iskolai osztályok tantárgyai";
    }
}
