﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolClasses
{
    public class SchoolClassesTeachersViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Osztályok tanárai";
    }
}
