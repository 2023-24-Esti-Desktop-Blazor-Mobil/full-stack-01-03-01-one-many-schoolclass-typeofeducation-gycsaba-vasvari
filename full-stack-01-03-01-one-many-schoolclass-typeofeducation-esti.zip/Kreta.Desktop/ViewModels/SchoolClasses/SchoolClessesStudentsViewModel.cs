﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolClasses
{
    public class SchoolClessesStudentsViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Iskolai osztályok diákjai";
    }
}
