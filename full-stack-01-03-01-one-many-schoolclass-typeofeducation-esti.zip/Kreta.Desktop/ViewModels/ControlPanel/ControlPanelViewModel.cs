﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.ControlPanel
{
    public class ControlPanelViewModel: BaseViewModel
    {
        public ControlPanelViewModel()
        {
                
        }
    }
}
