﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolSubjects
{
    public class SubjectsOfTeachersViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Tanárok tantárgyai";
    }
}
