﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.SchoolSubjects
{
    public class SubjectsOfSchoollClassesViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Osztályok tantárgyai";
    }
}
