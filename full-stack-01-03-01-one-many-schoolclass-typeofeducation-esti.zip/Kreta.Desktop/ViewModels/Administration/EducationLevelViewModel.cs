﻿using Kreta.Desktop.ViewModels.Base;

namespace Kreta.Desktop.ViewModels.Administration
{
    public partial class EducationLevelViewModel : BaseViewModel
    {
        public string Title { get; set; } = "Tanulmányi szint kezelése";
    }
}
