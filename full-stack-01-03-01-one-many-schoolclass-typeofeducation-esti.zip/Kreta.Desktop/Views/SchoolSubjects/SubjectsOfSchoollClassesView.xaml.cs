﻿using System.Windows.Controls;

namespace Kreta.Desktop.Views.SchoolSubjects
{
    /// <summary>
    /// Interaction logic for SubjectsOfSchollClasses.xaml
    /// </summary>
    public partial class SubjectsOfSchoollClassesView : UserControl
    {
        public SubjectsOfSchoollClassesView()
        {
            InitializeComponent();
        }
    }
}
