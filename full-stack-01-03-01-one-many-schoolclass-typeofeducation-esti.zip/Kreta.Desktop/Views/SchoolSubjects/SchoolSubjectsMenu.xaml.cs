﻿using System.Windows.Controls;


namespace Kreta.Desktop.Views.SchoolSubjects
{
    /// <summary>
    /// Interaction logic for SchoolCitizensMenuButton.xaml
    /// </summary>
    public partial class SchoolSubjectsMenu : UserControl
    {
        public SchoolSubjectsMenu()
        {
            InitializeComponent();
        }
    }
}
