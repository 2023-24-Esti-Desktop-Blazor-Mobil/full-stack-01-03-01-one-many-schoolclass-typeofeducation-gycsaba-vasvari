﻿using System.Windows.Controls;

namespace Kreta.Desktop.Views.SchoolClasses
{
    /// <summary>
    /// Interaction logic for SchoolCitizensMenuButton.xaml
    /// </summary>
    public partial class SchoolClassesMenu : UserControl
    {
        public SchoolClassesMenu()
        {
            InitializeComponent();
        }
    }
}
