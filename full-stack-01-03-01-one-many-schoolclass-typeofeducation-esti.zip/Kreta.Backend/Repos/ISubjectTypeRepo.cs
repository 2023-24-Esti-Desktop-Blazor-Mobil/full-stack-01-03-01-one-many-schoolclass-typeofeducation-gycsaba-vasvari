﻿using Kreta.Shared.Models;

namespace Kreta.Backend.Repos
{
    public interface ISubjectTypeRepo : IRepositoryBase<SubjectType>
    {
    }
}
