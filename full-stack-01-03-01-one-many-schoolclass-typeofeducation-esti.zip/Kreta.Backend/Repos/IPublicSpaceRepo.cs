﻿using Kreta.Shared.Models;

namespace Kreta.Backend.Repos
{
    public interface IPublicSpaceRepo : IRepositoryBase<PublicSpace>
    {
    }
}
