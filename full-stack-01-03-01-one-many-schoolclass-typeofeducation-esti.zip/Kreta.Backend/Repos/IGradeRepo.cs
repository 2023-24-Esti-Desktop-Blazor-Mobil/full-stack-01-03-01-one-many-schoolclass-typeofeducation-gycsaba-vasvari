﻿using Kreta.Shared.Models;

namespace Kreta.Backend.Repos
{
    public interface IGradeRepo : IRepositoryBase<Grade>
    {
    }
}
