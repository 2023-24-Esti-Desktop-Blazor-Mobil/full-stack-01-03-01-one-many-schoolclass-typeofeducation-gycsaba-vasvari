﻿using Kreta.Shared.Dtos;
using Kreta.Shared.Models;

namespace Kreta.Shared.Assamblers
{
    public class SubjectTypeAssambler : Assambler<SubjectType, SubjectTypeDto>
    {
        public override SubjectTypeDto ToDto(SubjectType domainEntity)
        {
            throw new NotImplementedException();
        }

        public override SubjectType ToModel(SubjectTypeDto dto)
        {
            throw new NotImplementedException();
        }
    }
}
