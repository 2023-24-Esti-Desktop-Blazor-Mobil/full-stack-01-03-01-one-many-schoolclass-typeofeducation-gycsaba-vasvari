﻿using Kreta.Shared.Dtos;
using Kreta.Shared.Parameters;

namespace Kreta.Shared.Extensions
{
    public static class StudentQueryParametersExtension
    {        
    }
}
