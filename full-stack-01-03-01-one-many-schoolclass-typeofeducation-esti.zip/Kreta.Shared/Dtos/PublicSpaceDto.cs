﻿namespace Kreta.Shared.Dtos
{
    public class PublicSpaceDto
    {
        public Guid Id { get; set; }
        public string NameOfPublicSpace { get; set; } = string.Empty;
    }
}
