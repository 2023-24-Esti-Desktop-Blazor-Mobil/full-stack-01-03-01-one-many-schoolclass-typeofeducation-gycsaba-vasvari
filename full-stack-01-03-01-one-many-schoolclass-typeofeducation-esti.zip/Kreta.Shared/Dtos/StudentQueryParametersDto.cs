﻿namespace Kreta.Shared.Dtos
{
    public class StudentQueryParametersDto
    {
    }
}
