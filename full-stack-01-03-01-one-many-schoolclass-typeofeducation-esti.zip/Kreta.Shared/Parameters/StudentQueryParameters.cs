﻿namespace Kreta.Shared.Parameters
{
    public class StudentQueryParameters 
    { 
    

    }
}
