﻿namespace Kreta.Shared.Models
{
    public enum SchoolClassType { ClassA, ClassB, ClassC }
}
